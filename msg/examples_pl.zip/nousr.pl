Zalogowanie sie twoim znakiem jest zabronione!
