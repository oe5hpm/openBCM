
** %m  ** QTH: city, bbs_loc., country * Admin: XX0XXX

Wykaz katalogow komenda 'd b' * Mowa poczta 'd n' * Pomoc komenda 'h'

To jest ograniczone zarejestrowanie sie goscia mozliweotylko czytanie.
Aby dostac uprawnienia napisz prosbe e-mail'em do sysopa i podaj swoj
znak i twoje haslo (maksimum. 8 znakow).


