
                         Sysop-commands
                        ================

MKDIR <naza_kataliogu>      Tworzy katalog o <nazwa_katalogu>.
lub MD

RMDIR <nazwa_katalogu>      Usuniecie (pustego) katalogu.
lub RD

RM <plik>                   Usuniecie podanego pliku.
lub DEL

CP <plik> <nowy_plik>       Kopiowanie pliku.
lub COPY

MV <plik> <nowy_plik>       Zmienia nazwe pliku na nowa.
lub MOVE                     

FSE <plik>                  Wykonuje opis i CALL z <pliku>.

FSE <plik>                  Kasuje opis i CALL z <pliku>.
