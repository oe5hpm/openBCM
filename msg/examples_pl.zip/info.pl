Mailbox OpenBCM %v

tu nalezy wpisac jakies info o stacji /bcm/msg/info.pl