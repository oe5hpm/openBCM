
%n, dziekuje za wizyte na naszym OpenBCM %v
Zagladaj czesciej - serdecznie zapraszam!
73 Bye bye! de %m

