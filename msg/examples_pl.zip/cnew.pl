HELP przedstawia najprzydatniejsze komendy!
