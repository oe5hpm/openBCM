FileSurf-Help
=============
   
CD [Katalog]           Dostep do katalogu poprzez podana sciezke dotepu.
albo CHDIR,            Jesli zaden parametr nie jest podany, to bedziesz
                       w biezacym katalog roboczym.

XDIR                   Przedstawia pliki biezacej sciezki dostepu.
                       Tez CALL i krotki opis plikow jest przedstawiony.

DIR [opcje] [katalog]  Przedstawia pliki danej sciezki dostepu. Jesli zaden 
                       parametr jest podany, pokazane sa pliki biezacego
		       katalogu.
                       Mozliwe opcje:
                       -D: sortowanie plikow wg czasu-modyfikacji 
                       -S: sortowanie plikow wg wielkosci 
                       -N: nie sortuj (ten sposob, ktory pliki beda wylistowane
                           w porzadku ich tworzenia)

LS [opcje] [katalog]   Wykonuje to samo jak DIR, z wyjatkiem tego ze katalog
                       zawartosc-katalogu jest podana w formie skroconej.
                       Przy wpisaniu opcje -L, pokaze pelny format.

PATH                   Pokazuje sciezke dostepu do katalogu, z ktorego
                       uzytkownik moze korzystac i do ktorych uzytkownik
		       moze napisac.

NEW <nazwa>            Pokazuje nowe pliki. W celu Zmniejszenia wyswietlenia
                       wykazu wpisz poszukiwana "nazwe".

FIND <nazwa>           Poszukuje "nazwa" w wszystkich nazwach zbioru filesurf.

INFO <plik>            Pokaze widoczna jakas informacja ponad plikiem.

VIEW <plik>            Pokaze plik-archivalny.

GET <plik>             Pobieranie danego pliku w formacie tekstowym.
lub READ 
lub TYPE               !!! Nie mozna przeczytac pliku binarnego !!!
lub CAT                !!!        uzywajac tej komendy          !!!
lub RTEXT 

7GET <plik>            Wysyla dany plik w formacie 7Plus.

7MAIL <plik> <czesci>  Wysyla dany plik jako 7Plus biuletyn do Mailboxa.

BGET <plik>            Wysyla dany plik w formacie AutoBIN.
lub BIN 
lub RPRG 

BMAIL <plik>           Wysyla dany plik jako AutoBIN wiadomosc do katalogu
                       uzytkownika.

BSGET <plik> <czesci>  Wysyla dany plik w binarnych czesciach.

DGET <plik>            Wysyla dany plik w formacie DIDADIT.

YGET <plik>            Wysyla dany plik w formacie YAPP.
lub RYAPP 

PUT <plik>             Zapisanie danego pliku w format tekstowy.
lub WTEXT 

BPUT <plik>            Zapisanie danego pliku w formacie AutoBIN.
lub  WPRG 

DPUT                   Zapisanie pliku w formacie DIDADIT.

YPUT <plik>            Zapisanie danego pliku w formacie YAPP.
lub WYAPP 

HELP                   Pokazuje ten tekst.
lub ?

QUIT                   Konczy prace z FileSurf i wraca do Mailboxa.
lub BYE
lub EXIT 

