Zalogowanie mozliwe tylko z haslem! 
