To jest archiwum plikow z Mailboxa OpenBCM %v %m
----------------------------------------------------------------------------
(H)elp       Pokazanie podpowiedzi i opis komend FileSurf
(I)nfo       Krotka informacja o pliku
(F)ind       Poszukuje nazwy w zbiorach filesurf
(V)iew       Pokazuje pliki archiwizowane (ZIP, ARJ, LHA, RAR...)
(B)in        Czytanie pliku jako format AUTOBIN (bsget jest dobry!)
(BM)ail      Wysyla plik jako AutoBIN do katalogu uzytkownika, w BBS'ie
(BS)get      Czytanie pliku w formacie BS - podzielonego na czesci
(7G)et       Czytanie pliku w formacie 7plus
(7)mail      Wysyla plik jako 7plus, do katalogu uzytkownika w BBS'ie
(DG)et       Czytanie pliku w formacie DIDIADIT
(YG)et       Czytanie pliku w formacie YAPP

