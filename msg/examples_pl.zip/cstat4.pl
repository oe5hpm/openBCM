
**  %m ** QTH: city, bbs_loc, country * Admin: XX0XXX

Przepraszam, twoj znak uzytkownika jest nieznany dla tego systemu skrzynki
poczty elektronicznej.
Sysop bedzie teraz poinformowany, sprobuj znowu, gdy sysop da tobie
uprawnienia dostepu!

