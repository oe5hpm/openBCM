
Prosze wpisz swoje imie, qth, oraz kod pocztowy i twoj (Home_BBS)!
A N <imie>  A QT <miejscowosc>  A Z <kod_pocztowy>   A F <HOME_BBS>
           A HT 0 Zmiana wygladu po polaczeniu via http
