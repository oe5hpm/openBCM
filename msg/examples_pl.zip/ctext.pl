 * Mailbox * %k biuletynow-maili (%e nowych)

** %m  ** QTH: city, bbs_loc, country  * Admin: XX0XXX
               Dzis jest: %d, godz. %t

Wykaz katalogow 'D B', wykaz wszystkich biuletynow 'D N', help 'H'


