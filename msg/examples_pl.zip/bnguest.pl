Ten znak jest juz w uzyciu w CB BCMNET! Aby uniknac niewlasciwego
znaku i korzystania mozesz tylko zarejestrowac sie jako gosc.

Pelniejsze informacje dla zarejestrowania gosci HELP BCMNET
